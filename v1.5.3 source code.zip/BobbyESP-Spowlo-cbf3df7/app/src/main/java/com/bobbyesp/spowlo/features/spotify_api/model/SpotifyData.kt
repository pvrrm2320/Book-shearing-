package com.bobbyesp.spowlo.features.spotify_api.model

enum class SpotifyDataType {
    TRACK,
    ALBUM,
    PLAYLIST,
    ARTIST
}