package com.bobbyesp.spowlo.ui.theme

import androidx.compose.material3.Shapes

val Shapes = Shapes(
)