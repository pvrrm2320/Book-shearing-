# MODS DOWNLOADER FOR SPOWLO

ThIs is the mod downloader for Spowlo. It is a simple feature that allows you to download Spotify
mods using the xManager API.

It is actually unavailable since the xManager team told me to remove it from the app. I will try to
create mods by myself and add them to the app.
So sorry for the inconveniences, but they are actually a non-profit team and making this feature
will make decrease their income money.